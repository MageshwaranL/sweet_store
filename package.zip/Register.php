<?php include './Include/navbar.php'; ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <section>
        <div class="relative flex justify-center max-h-full overflow-hidden lg:px-0 md:px-12">
            <div
                class="relative z-10 flex flex-col flex-1 px-4 py-10 bg-white shadow-2xl lg:py-24 md:flex-none md:px-28 sm:justify-center">
                <div class="w-full max-w-md mx-auto md:max-w-sm md:px-0 md:w-96 sm:px-4">
                    <div class="flex flex-col">
                        <div>
                            <h2 class="text-4xl text-black">Let's get started!</h2>
                            <p class="mt-2 text-sm text-gray-500">
                                Complete the details below so I can process your request and then
                                schedule a time to discuss your goals.
                            </p>
                        </div>
                    </div>
                    <form>
                        <input autocomplete="false" name="hidden" style="display: none">
                        <input name="_redirect" type="hidden" value="#">
                        <div class="mt-4 space-y-6">
                            <div>
                                Have an account? <span><a class="underline" href="./login.php"> Log in </a></span>
                            </div>
                            <div>
                                <label class="block mb-3 text-sm font-medium text-gray-600" name="name">
                                    Contact
                                </label>
                                <input
                                    class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="Your Email">


                            </div>
                            <div class="col-span-full">
                                <label class="block mb-3 text-sm font-medium text-gray-600" name="company">
                                    Country
                                </label>
                                <input
                                    class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="India">
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        First Name
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        Last Name
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                            </div>

                            <div class="col-span-full">
                                <label class="block mb-3 text-sm font-medium text-gray-600" name="company">
                                    Company
                                </label>
                                <input
                                    class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="India">
                            </div>
                            <div class="col-span-full">
                                <label class="block mb-3 text-sm font-medium text-gray-600" name="company">
                                    Address
                                </label>
                                <input
                                    class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="India">
                            </div>
                            <div class="col-span-full">
                                <label class="block mb-3 text-sm font-medium text-gray-600" name="company">
                                    Apartment
                                </label>
                                <input
                                    class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="India">
                            </div>

                            <div class="grid grid-cols-2 gap-4">
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        City
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        State
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        Pincode
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                                <div class="">

                                    <label class="block mb-3 text-sm font-medium text-gray-600" name="email">
                                        Mobile Number
                                    </label>
                                    <input
                                        class="block w-full px-6 py-3 text-black bg-white border border-gray-200 appearance-none rounded-xl placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="email@example.com" autocomplete="off" type="email">
                                </div>
                            </div>


                            <div class="col-span-full">
                                <button
                                    class="items-center justify-center w-full px-6 py-2.5 text-center text-white duration-200 bg-black border-2 border-black rounded-full nline-flex hover:bg-transparent hover:border-black hover:text-black focus:outline-none focus-visible:outline-black text-sm focus-visible:ring-black"
                                    type="submit">
                                    Submit your request
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="hidden bg-white lg:block lg:flex-1 lg:relative sm:contents">
                <div class="absolute inset-0 object-cover w-full h-full bg-white" alt="" height="1866" width="1664">
                    <img class="object-center w-full h-auto bg-gray-200" src="./Assest/login.jpg" alt="" width="1310"
                        height="873">
                </div>
            </div>
        </div>
    </section>

</body>

</html>