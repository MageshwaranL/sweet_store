<?php include './Include/navbar.php'; ?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>





    <!-- Alphin alpinejs  -->
    <script src="//unpkg.com/alpinejs" defer></script>

    <link href="./output.css" rel="stylesheet">
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->

    <script>
    tailwind.config = {
        darkMode: "class",
        container: {
            padding: {
                DEFAULT: '1rem',
                sm: '2rem',
                lg: '4rem',
                xl: '5rem',
                '2xl': '6rem',
            },
        },
        theme: {
            container: {
                center: true,
            },
            fontFamily: {
                sans: ["Roboto", "sans-serif"],
                body: ["Roboto", "sans-serif"],
                mono: ["ui-monospace", "monospace"],
            },
        },

    };
    </script>


</head>

<body>

    <?php include 'banner.php'; ?>  
    <?php include 'productcategories.php'; ?>
    <?php include 'userreview.php' ?>
    <?php include 'testmonial.php'; ?>
    <?php include 'stats.php'; ?>
    <?php include 'videocarousel.php' ?>
    <?php include 'contact.php'; ?>
    <?php include 'footer.php'; ?>


    <!-- TW Elements is free under AGPL, with commercial license required for specific uses. See more details: https://tw-elements.com/license/ and contact us for queries at tailwind@mdbootstrap.com -->
    <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/tw-elements.umd.min.js"></script>
</body>

</html>